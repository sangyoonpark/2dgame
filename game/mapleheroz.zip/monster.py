from pico2d import *
from baseobj import *
from cameraobj import *
from floor import*
import random
class monster():
    def __init__(self):
        self.classname="MONSTER"
        self.total_frame=0.0
        self.monstertype=None
        self.image=None
        #if monste.image==None:
        #    if self.monstertype==0:
        #        self.image = load_image('./resource/mychar0/LSRR0.bmp')
      #  if charobj.bodyimage==None and self.bodytype!=-1:
      #      if self.bodytype==0:
      #       self.bodyimage=load_image('./resource/mychar0/body/bodyspritesheettype0.png')
   #     self.anixsize=[]
   #     self.aniysize=[]
        self.rectpos=RECT()
        self.rectpos.right=0
        self.rectpos.left=0
        self.rectpos.bottom=0
        self.rectpos.top=0
        self.xpos=0
        self.ypos=0
        self.xsize=0
        self.ysize=0
   #     self.maxaninum=[0,0,0,0,0,0]
        self.LV=1
        self.fullhp=50
        self.giveexp=30
        self.hp=0
        self.armor=0
        self.MState=0
        self.xspeed=0
        self.yspeed=0
        self.aninum=0
        self.ysize=80
        self.xsize=80
        self.bulletnum=0
        self.RorL=1
        self.gravitymode=0
        self.jumcount=0
        self.movecount=0.0
        self.maxaninum=[5,6,1,7]
        # 1 멀뚱->3 2걷기->4 3피격->1  4 쓰러짐4
        self.framecount=0
        self.move=1
        self.changeturncount=3.0
        self.standcount=4.0


    def initAll(self,rectposleft, rectpostop, rectposright, rectposbottom, xpos1, ypos1, xsize1, ysize1, hp1, mp1, armor1, xspeed1, yspeed1, bodytype1=0, bodyaninum1=0, hairposleft=0,hairpostop=0,hairposright=0,hairposbottom=0, hairtype1=0):
            self.fullmp = mp1
            self.fullhp = hp1
            self.hp = hp1
            self.mp = mp1
            self.armor = armor1
            self.xspeed = xspeed1
            self.yspeed = yspeed1
            self.bodytype = bodytype1
            self.aninum = bodyaninum1
            self.rectpos.Right(rectposright)
            self.rectpos.Bottom(rectposbottom)
            self.rectpos.Left(rectposleft)
            self.rectpos.Top(rectpostop)
            self.xpos =xpos1
            self.ypos =ypos1
            self.xsize=xsize1
            self.ysize=xsize1
    def initinform(self,xsize1,ysize1,hp1,armor1,xspeed1,mtype):
            self.fullhp = hp1
            self.hp = hp1
            self.armor = armor1
            self.xspeed = xspeed1
            self.xsize=xsize1
            self.ysize=xsize1
            if mtype==0 and self.image==None:
                self.image=load_image('./resource/monsters/monster011.jpg')


    def initManimax(self,a1, a2, a3, a4,  a5,  a6 = 0):
	    self.maxaninum=[a1,a2,a3,a4]


    def initpos(self,l,b,r,t):
         self.rectpos.right=r
         self.rectpos.left=l
         self.rectpos.bottom=b
         self.rectpos.top=t
         self.xsize=self.rectpos.right-self.rectpos.left
         self.ysize=self.rectpos.top-self.rectpos.bottom
    def draw(self,camera=None):
        if type(camera) is cameraobj:
            if self.RorL==2:
                self.image.clip_draw(self.aninum*150,1050-(300*self.MState),150,150,(self.rectpos.right+self.rectpos.left)/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom)/2-camera.ypos,150,150)
            if self.RorL==1 or self.RorL==0:
                  self.image.clip_draw( (self.maxaninum[self.MState]-1)*150-self.aninum*150,900-(300*self.MState),150,150,(self.rectpos.right+self.rectpos.left)/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom)/2-camera.ypos,150,150)
                  #clipdraw는 그려야하는x위치,그려야하는y위치,짜를크기,짜를크기,실제적용위치,실제적용위치,실제그려질크기,실제그려질크기
                  #즉 중앙기준으로 켜지는구나!!!







    def update(self,frame_time):
        #self.xpos+=3
        self.total_frame=self.total_frame+frame_time
        #턴을 바꾸는것과
        if self.changeturncount>0:
            self.changeturncount=self.changeturncount-frame_time
        elif self.changeturncount<=0:
           self.RorL=random.randint(1,2)
           self.changeturncount=random.randint(5,10)


        self.rectpos.right=self.rectpos.left+self.xsize
        self.rectpos.top=self.rectpos.bottom+self.ysize
        self.xpos=(self.rectpos.right+self.rectpos.left)/2
        self.ypos=(self.rectpos.top+self.rectpos.bottom)/2
        self.xsize=self.rectpos.right-self.rectpos.left
        self.ysize=self.rectpos.top-self.rectpos.bottom
#몇초마다 방향을바꿔줌.

        #0일때 서있는경우 0.1초
        if self.MState==0 and self.total_frame>0.5:
                if self.aninum<self.maxaninum[self.MState]-1:
                    self.aninum+=1
                else:
                    x=random.randint(0,10)
                    if x>5:
                        self.MState=1
                    self.aninum=0
                self.total_frame=0.0

        if self.MState==1 and self.total_frame>0.2:
        #점프구현
                if self.aninum<self.maxaninum[self.MState]-1:
                    self.aninum+=1
                elif self.aninum>=self.maxaninum[self.MState]-1:
                    x=random.randint(0,90)
                    if x>80:
                        self.MState=0
                        self.aninum=0
                    else :
                        self.aninum=0

                self.total_frame=0.0

        if self.MState==3 and self.total_frame>0.5:
                if self.aninum<self.maxaninum[self.MState]-1:
                    self.aninum+=1
                else:
                    self.MState=0
                    self.aninum=0
                self.total_frame=0.0

        if self.RorL==1:


           if self.MState==1:
                self.rectpos.left+=20*frame_time
                self.rectpos.right=self.rectpos.left+self.xsize
        if self.RorL==2:
                self.rectpos.left+=0
                if self.MState==1:
                    self.rectpos.left-=20*frame_time
                    self.rectpos.right=self.rectpos.left+self.xsize

        #점프구현



        if self.gravitymode==1:
            self.rectpos.bottom-=2



