from pico2d import *
from baseobj import *
from charobj import *
from cameraobj import *
from monster import *
class Floor():

    def __init__(self,floorkind=0):
        if floorkind==0:
            self.image=load_image('grass.png')
        self.rectpos=RECT()
        self.rectpos.right=0
        self.rectpos.left=0
        self.rectpos.top=0
        self.rectpos.bottom=0

    def initfloor(self,l,b,r,t):
         self.rectpos.right=r
         self.rectpos.left=l
         self.rectpos.bottom=b
         self.rectpos.top=t



    def update(self,frame_time,a=None):
          #충돌쳌패턴1 캐릭의밑과 바닥의 top이같아진경우 멈춤
        if a.classname=="CHAROBJ":
            if a.rectpos.bottom-self.rectpos.top<1 and a.xpos>self.rectpos.left and a.xpos<self.rectpos.right:
                a.gravitymode=0
                if a.CharState==2:
                    if a.move==0:
                        a.CharState=0
                    elif a.move==1:
                        a.CharState=1
            else :
                a.gravitymode=1
        if  a.classname=="MONSTER":
             if a.rectpos.bottom-self.rectpos.top<1 and a.xpos>self.rectpos.left and a.xpos<self.rectpos.right:
                a.gravitymode=0
             else :
                 a.gravitymode=1



    def draw(self,myc):
    #    if type(myc) is cameraobj:
             self.image.draw( (self.rectpos.right+self.rectpos.left)/2-myc.xpos,(self.rectpos.top+self.rectpos.bottom)/2-myc.ypos,self.rectpos.right-self.rectpos.left,self.rectpos.top-self.rectpos.bottom)

        # draw 함수 중간점,중간점,크기,크기
        #win api 식과 동일하게 선언한 rect이므로 python에도 보기와같이 적용하기에는 이러한 식이필요.
