import game_framework
import main_state
import start_state
from pico2d import *
#아나 파일이름 왜못바꿔 ㅠ 캐릭선택창임
name = "TutorialState"

kimage = None
mimage=None
kiconimg=None
miconimg=None
bodyimg=None
bodytype0=None
bodynum=0

hairimg=None
hairtype0=None
hairnum=0

jobdata=1
logo_time = 0.0
mx=0
my=0
eyenum=0
eyetype0=None
eyeimg=None
#이 데이터를 외부에 널리알게하는법
def enter():
    global bodytype0
    global kimage,mimage
    global kiconimage
    global miconimage
    global bodyimage
    global eyetype0
    global eyeimg
    global hairtype0
    global hairimg
    open_canvas(800,600)
    bodytype0=load_image('./resource/mychar0/body/bodyspritesheettype0.png')
    bodyimage=load_image('./resource/mychar0/body/bodyspritesheettype0.png')
    kimage = load_image('./resource/etcimg/kazeselectimg.png')
    mimage=load_image('./resource/etcimg/mabupsaimg.png')
    kiconimage=load_image('./resource/etcimg/kazeicon.png')
    miconimage=load_image('./resource/etcimg/mabupsaicon.png')
#    eyetype0=load_image('./resource/mychar0/eye/eyetype0sheet.png')
#    eyeimg=load_image('./resource/mychar0/eye/eyetype0sheet.png')
    eyetype0=load_image('./resource/mychar0/eye/eyest0.png')
    eyeimg=load_image('./resource/mychar0/eye/eyest0.png')
    hairtype0=load_image('./resource/mychar0/hair/hairsheet0.png')
    hairimg=load_image('./resource/mychar0/hair/hairsheet0.png')
def exit():
    global kimage,mimage
    global bodyimage
    global kiconimage
    global miconimage
    del(kimage)
    del(mimage)
    del(kiconimage)
    del(miconimage)
    del(bodyimage)
    close_canvas()

def update(frame_time):
    global kimage,mimage
    global bodyimg
    global bodynum
    global jobdata
    global mx
    global my
    global eyenum
    global eyeimg
    global eyenum
    global bodytype0
    if bodynum==0:
        bodyimg=bodytype0
    if eyenum==0:
        eyeimg=eyetype0
    if mx>0 and mx<100 and my>500 and my<600 :
        jobdata=1
    if mx>0 and mx<100 and my>400 and my<500:
        jobdata=2

  #  if mx>400:
  #      jobdata=1
  #  else :
  #      jobdata=2
   # global logo_time
   # if(logo_time>=2.0):
   #     logo_time=0
   #     del(image)
   #     close_canvas()
   #     game_framework.push_state(main_state)
   # delay(0.1)
   # logo_time+=0.1


def draw():
    global bodyimg
    global bodynum
    global kimage,mimage
    global jobdata
    global kiconimage
    global miconimage
    global eyetype0
    global eyeimg
    global hairtype0
    global hairimg
    clear_canvas()
     #  bodyimg.clip.draw(0,0,39,64,250,250)

    if jobdata==1:
        kimage.draw(400,300)
    if jobdata==2:
        mimage.draw(400,300)
    #이미지는 배열화되지않습니다.
    kiconimage.draw(50,550)
    miconimage.draw(50,450)
   # if bodynum==0:
   #  bodyimg.clip_draw(0,0,900,500,250,250)
 # x y 39 64
    bodyimg.clip_draw(0,836,39,64,450,300,39*1.5,64*1.5)
    eyeimg.clip_draw(26,0,26,18,450+4.5,300+13,26*1.5,18*1.5)
    hairimg.clip_draw(0,0,47,45,450+4.5,300+30,47*1.5,45*1.5)
 #   bodyimg.draw(250,250,300,300)

    update_canvas()
    pass


#정보를 다 해논후 클릭시 데이터 init해준다.
#일단 캐릭 커스텀을직접클릭하고.
def handle_events():

    global mx
    global my
    global kimage,mimage
    global kiconimage
    global miconimage
    global bodynum
    global jobdata
    global eyenum
    global hairnum
    events = get_events()
    for event in events:
        if event.type ==SDL_QUIT:
            close_canvas()
        if event.type==SDL_MOUSEMOTION:
            mx,my=event.x,600-event.y
        if event.type==SDL_MOUSEBUTTONDOWN:
            if event.x>200 and event.x<300 and (600-event.y)>50 and (600-event.y)<100: #번호제대로
                del(kimage)
                del(mimage)
                del(kiconimage)
                del(miconimage)
                close_canvas()
                game_framework.push_state(main_state)














                game_framework.chardata_init(main_state,jobdata,bodynum,eyenum,hairnum)



def pause(): pass


def resume(): pass






