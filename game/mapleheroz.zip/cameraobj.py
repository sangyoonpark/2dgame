from pico2d import *
from baseobj import *
from charobj import *


class cameraobj():

    def __init__(self):
        self.xpos=0
        self.ypos=0

    def update(self,a):
        if type(a) is baseobj:
         #   if a.rectpos.bottom-self.rectpos.top<1:
                a.gravitymode=0
        else :
            if a.rectpos.left<640:
                self.xpos=0
            elif a.rectpos.left>640 and a.rectpos.left<(2099-640):
                self.xpos=a.rectpos.left-640
            elif a.rectpos.left>(1459):
                self.xpos=(2099-1280) #높을수록 뒤로가진다.
        #계속맵의 양쪽끝점을알아야한다.고로 맵 sizeobj필요할듯 현재는 0 ~2099
                #내캐릭 pos가 1000이면 camera는 360이라 1000-360으로 640에있게보임 즉
                #포스가 2100이면 -1400해서
        #if myc.rectpos.left<640:
        #        self.xpos=0
        #elif myc.rectpos.left>640:
        #        self.xpos=myc.rectpos.left-640