from pico2d import *
from baseobj import *
from cameraobj import *
from floor import*
import random
class charobj():
    bodyimage=None
    image=None
    eyeimage=None
    hairimage=None
    swordimage=None
    def __init__(self):
        self.classname="CHAROBJ"
        self.bodytype=0
        self.eyetype=0
        self.hairtype=0
        self.total_frame=0.0
        self.swordtype=0
        if charobj.image==None:
            #self.bodyimages=[[0 for i in range(12)]for row in range(10)]
            #self.bodyimage[0][0]=imageC("body",0,0)
            #self.bodyimages[0]=charobj()
            #self.bodyimages[0][0]=load_image('./resource/mychar0/body/rstand1_0')
            #self.bodyimages[0][1]=load_image('./resource/mychar0/body/rstand1_1')
            #self.bodyimages[0][2]=load_image('./resource/mychar0/body/rstand1_2')
            #self.bodyimages[0][3]=load_image('./resource/mychar0/body/rstand1_3')
            #self.bodyimages[0][4]=load_image('./resource/mychar0/body/rstand1_4')
            #이제 walk
            #self.bodyimages[1][0]=load_image('./resource/mychar0/body/rwalk1_0')
            #self.bodyimages[1][1]=load_image('./resource/mychar0/body/rwalk1_1')
            #self.bodyimages[1][2]=load_image('./resource/mychar0/body/rwalk1_2')
            #이미지를 담을수없다 why?
            #현재 배열에 이미지말고 함수 클래스는넣어짐. 클래스가 넣어진다는것은 이미지출력이가능?
            # 0 스탠드 1 walk 2점프 3공격 4스킬 5사다리 총6개
            # 0스탠드 1번 워크
            # self.image = load_image('./resource/monster_ghost_stand.png')
            #이미지를 여러개 이미 로드한후 차례차례꺼낸다
            self.image = load_image('./resource/mychar0/LSRR0.bmp')
      #  if charobj.bodyimage==None and self.bodytype!=-1:
      #      if self.bodytype==0:
      #       self.bodyimage=load_image('./resource/mychar0/body/bodyspritesheettype0.png')
   #     self.anixsize=[]
   #     self.aniysize=[]
        self.rectpos=RECT()
        self.rectpos.right=0
        self.rectpos.left=0
        self.rectpos.bottom=0
        self.rectpos.top=0
        self.xpos=0
        self.ypos=0
        self.xsize=0
        self.ysize=0
   #     self.maxaninum=[0,0,0,0,0,0]
        self.LV=1
        self.fullhp=50
        self.fullmp=0
        self.fullexp=50
        self.hp=0
        self.mp=0
        self.armor=0
        self.CharState=0
        self.xspeed=0
        self.yspeed=0
        self.aninum=0
        self.ysize=80
        self.xsize=80
        self.bulletnum=0
        self.RorL=0
        self.gravitymode=1
        self.jumcount=0
        self.aniypos=[900,900-64,900-128,900-190,900-254,900-316,900-381,900-445]

        self.anixsize=[39,39,39,68,55,72,44]
        self.aniysize=[64,64,62,64,62,65,64]
        self.maxaninum=[5,4,1,3,3,3,2]
        self.framecount=0
        self.anixpos=[39*5*2,39*4*2,39*1*2,68*3*2,55*3*2,72*3*2,44*2*2] # *2해서 뒤에서부터.
        self.move=0
        self.eyexpos=[-40,0,40]
        self.eyeypos=[0,0,-23]
        self.swordypos=[-60,-60,60,0]
        self.swordxpos=[0,0,0,0]
    def initchardata(self,job=0,body=0,eye=0,hair=0):
        self.bodytype=body
        self.eyetype=eye
        self.hairtype=hair
        if self.bodytype==0:
             self.bodyimage=load_image('./resource/mychar0/body/bodyspritesheettype0.png')
        if self.eyetype==0:
            self.eyeimage=load_image('./resource/mychar0/eye/eyetype0sheet.png')
        if self.hairtype==0:
            self.hairimage=load_image('./resource/mychar0/hair/hairsheet0.png')
        if self.swordtype==0:
            self.swordimage=load_image('./resource/mychar0/sword/sword1.jpg')
    def initAll(self,rectposleft, rectpostop, rectposright, rectposbottom, xpos1, ypos1, xsize1, ysize1, hp1, mp1, armor1, xspeed1, yspeed1, bodytype1=0, bodyaninum1=0, hairposleft=0,hairpostop=0,hairposright=0,hairposbottom=0, hairtype1=0):
            self.fullmp = mp1
            self.fullhp = hp1
            self.hp = hp1
            self.mp = mp1
            self.armor = armor1
            self.xspeed = xspeed1
            self.yspeed = yspeed1
            self.bodytype = bodytype1
            self.aninum = bodyaninum1
            self.rectpos.Right(rectposright)
            self.rectpos.Bottom(rectposbottom)
            self.rectpos.Left(rectposleft)
            self.rectpos.Top(rectpostop)
            self.xpos =xpos1
            self.ypos =ypos1
            self.xsize=xsize1
            self.ysize=xsize1
            #size maxaninum
          #  self.anixsize=[39,39,39,68,55,72,44]
          #  self.aniysize=[64,64,62,64,62,65,64]
          #  self.maxaninum=[5,4,1,3,3,3,2]
    def initManimax(self,a1, a2, a3, a4,  a5,  a6 = 0):
	    self.maxaninum=[a1,a2,a3,a4,a5]


    def initpos(self,l,b,r,t):
         self.rectpos.right=r
         self.rectpos.left=l
         self.rectpos.bottom=b
         self.rectpos.top=t
         self.xsize=self.rectpos.right-self.rectpos.left
         self.ysize=self.rectpos.top-self.rectpos.bottom
    def draw(self,camera):
     #   if type(camera) is cameraobj: 1번이 오른쪽
            if self.RorL==1 or self.RorL==0:
                self.bodyimage.clip_draw(self.aninum*self.anixsize[self.CharState],self.aniypos[self.CharState]-self.aniysize[self.CharState],self.anixsize[self.CharState],self.aniysize[self.CharState],(self.rectpos.right+self.rectpos.left)/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom)/2-camera.ypos,self.anixsize[self.CharState]*1.5,self.aniysize[self.CharState]*1.5)
                self.swordimage.clip_draw( (self.maxaninum[self.CharState])*200-self.aninum*200,2400-(400*self.CharState),200,200,(self.rectpos.right+self.rectpos.left+  self.swordxpos[self.CharState])/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom+self.swordypos[self.CharState])/2-camera.ypos,200,200)
                if self.CharState==3:
                 self.eyeimage.clip_draw(26,0,26,18,(self.rectpos.right+self.rectpos.left+9+self.eyexpos[self.aninum])/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom+26+self.eyeypos[self.aninum])/2-camera.ypos,26*1.5,18*1.5)
                 self.hairimage.clip_draw(0,0,47,45,(self.rectpos.right+self.rectpos.left+9+self.eyexpos[self.aninum])/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom+60+self.eyeypos[self.aninum])/2-camera.ypos,47*1.5,45*1.5)
                else :
                   self.eyeimage.clip_draw(26,0,26,18,(self.rectpos.right+self.rectpos.left+9)/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom+26)/2-camera.ypos,26*1.5,18*1.5)
                   self.hairimage.clip_draw(0,0,47,45,(self.rectpos.right+self.rectpos.left+9)/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom+60)/2-camera.ypos,47*1.5,45*1.5)
         #clip자체가 그위 그위(밑에서부터시작이므로 위부터) 짜를크기 짜를크기 위치 위치 크기 크기
         #eye 원래 크기의 +7,20해준다.
            if self.RorL==2:
                self.bodyimage.clip_draw(self.anixpos[self.CharState]-self.anixsize[self.CharState]-self.aninum*self.anixsize[self.CharState],self.aniypos[self.CharState]-self.aniysize[self.CharState],self.anixsize[self.CharState],self.aniysize[self.CharState],(self.rectpos.right+self.rectpos.left)/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom)/2-camera.ypos,self.anixsize[self.CharState]*1.5,self.aniysize[self.CharState]*1.5)
                self.swordimage.clip_draw( self.aninum*200,2600-(400*self.CharState),200,200,(self.rectpos.right+self.rectpos.left+self.swordxpos[self.CharState])/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom+self.swordypos[self.CharState])/2-camera.ypos,200,200)
                if self.CharState==3:
                 self.eyeimage.clip_draw(0,0,26,18,(self.rectpos.right+self.rectpos.left-9-self.eyexpos[self.aninum])/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom+26+self.eyeypos[self.aninum])/2-camera.ypos,26*1.5,18*1.5)
                 self.hairimage.clip_draw(47,0,47,45,(self.rectpos.right+self.rectpos.left-9-self.eyexpos[self.aninum])/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom+60+self.eyeypos[self.aninum])/2-camera.ypos,47*1.5,45*1.5)
                else :
                   self.eyeimage.clip_draw(0,0,26,18,(self.rectpos.right+self.rectpos.left-9)/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom+26)/2-camera.ypos,26*1.5,18*1.5)
                   self.hairimage.clip_draw(47,0,47,45,(self.rectpos.right+self.rectpos.left-9)/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom+60)/2-camera.ypos,47*1.5,45*1.5)
#anixpos 앞에+@값너주는방식-> 500-
             #self.bodyimage.clip_draw(0,900-64,39,64,(self.rectpos.right+self.rectpos.left)/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom)/2-camera.ypos,39*1.5,64*1.5)
             # self.bodyimage.clip_draw(0,900-64,39,64,(self.rectpos.right+self.rectpos.left)/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom)/2-camera.ypos,self.rectpos.right-self.rectpos.left,self.rectpos.top-self.rectpos.bottom)
         #   self.bodyimage.clip_draw(0,900-64,39,64,(self.rectpos.right+self.rectpos.left)/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom)/2-camera.ypos,self.rectpos.right-self.rectpos.left,self.rectpos.top-self.rectpos.bottom)
            #원래 draw가 위치,위치 크기,크기 clip draw가 그려야하는위치,그위,짜를크기,짜를크기,위치,위치,크기,크기
           #   self.bodyimages[self.aninum].draw(self.xpos-camera.xpos,self.ypos-camera.ypos,self.xsize,self.ysize) #크기는안변함위치만
           # self.bodyimages[self.Charstate][self.aninum].draw(self.xpos-camera.xpos,self.ypos-camera.ypos,self.xsize,self.ysize) #크기는안변함위치만
            #  self.image.draw( (self.rectpos.right+self.rectpos.left)/2-camera.xpos,(self.rectpos.top+self.rectpos.bottom)/2-camera.ypos,self.rectpos.right-self.rectpos.left,self.rectpos.top-self.rectpos.bottom)
              #self.bodyimages[0].draw()
    def update(self,frame_time):
        #self.xpos+=3
        self.total_frame=self.total_frame+frame_time
        self.rectpos.right=self.rectpos.left+self.xsize
        self.rectpos.top=self.rectpos.bottom+self.ysize
        self.xpos=(self.rectpos.right+self.rectpos.left)/2
        self.ypos=(self.rectpos.top+self.rectpos.bottom)/2
        self.xsize=self.rectpos.right-self.rectpos.left
        self.ysize=self.rectpos.top-self.rectpos.bottom

        if self.total_frame>=0.01:
          #  print("gugu")
            if self.CharState==0 and self.total_frame>=0.2 :
                if self.aninum<=self.maxaninum[self.CharState]-1:
                    self.aninum+=1
                else:
                    self.aninum=0
                self.total_frame=0.0
            if self.CharState==1  and self.total_frame>=0.2:
                if self.aninum<=self.maxaninum[self.CharState]-1:
                    self.aninum+=1
                else:
                    self.aninum=0
                self.total_frame=0

            if self.CharState==3 and self.total_frame>=1.0:
                if self.aninum<=self.maxaninum[self.CharState]-1:
                    self.aninum+=1
                else:
                    self.CharState=0
                    self.aninum=0
                self.total_frame=0



        #점프구현
        if self.jumcount>0:
                self.aninum=0
                self.CharState=2
                self.rectpos.bottom+=(self.jumcount*6)
                self.jumcount-=1

        if self.RorL==1:


            if self.move==1:
                    self.rectpos.left+=500*frame_time
                    self.rectpos.right=self.rectpos.left+self.xsize

        if self.RorL==2:
                self.rectpos.left+=0

                if self.move==1:
                    self.rectpos.left-=500*frame_time
                    self.rectpos.right=self.rectpos.left+self.xsize
        if self.gravitymode==1 and self.jumcount==0:
                self.rectpos.bottom-=200*frame_time



        #self.rectpos.left+=2
        #self.rectpos.bottom+=2



