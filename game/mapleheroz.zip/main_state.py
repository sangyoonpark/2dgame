import random
import json
import os

from pico2d import *
from baseobj import *
from monster import *
from charobj import *
from  floor import *
from cameraobj import *
import game_framework
import title_state


#import character
#아직 그 개념을몰라서 다 쓴다.



name = "MainState"

boy = None
grass = None
font = None
mychar=None
floor=None

mapimg=None
bgimg=None
mycamera=None
testmonster=None
def enter():
    global mychar
    global bgimg
    global mapimg
    global floor
    global mycamera
    global testmonster
    #4:3 1280 960
    game_framework.reset_time()
    open_canvas(1280,960)
    #grass=Grass()

    mapimg=load_image('./resource/mapbg/mapleimag01.png')
    bgimg=load_image('./resource/mapbg/mapbgimg01.bmp')
    mychar=charobj()
    mycamera=cameraobj()
    floor=Floor(0)
    floor.initfloor(0,0,2098,229)
    #floor.initfloor(0,0,1208,229)
    #mychar.initAll(0, 500, 80, 580, 40, 540, 80, 80, 150, 100, 10, 20, 5, 0, 0, 30, 500, 50, 520, 0)
    mychar.initAll(0, 0, 0, 0, 400, 0, 80, 80, 150, 100, 10, 20, 5, 0, 0, 30, 500, 50, 520, 0)
    mychar.initManimax(4,3,4,2,3)
    mychar.initpos(0,229,60,319)
    testmonster=monster()
    testmonster.initinform(60,60,100,5,10,0)
    testmonster.initpos(680,229,740,289)

    # 60 90으로


def chardata_init(job,body,eye,hair):
    global mychar
    mychar.initchardata(0,body,eye,hair)
    #mychar.bodytype=0
    #mychar.jobtype=data1

def exit():
    pass


def pause():
    pass


def resume():
    pass


def update(frame_time):
    global mychar
    global floor
    global mycamera
    global testmonster

    mychar.update(frame_time)
    floor.update(frame_time,mychar)
    floor.update(frame_time,testmonster)

    mycamera.update(mychar)
    testmonster.update(frame_time)
   # mychar.bodyimages[0].update(mychar)

def handle_events():
  global mychar
  events = get_events()
  for event in events:
        if event.type ==SDL_QUIT:
            close_canvas()
        if event.type==SDL_KEYDOWN:
            if event.key==SDLK_LEFT :
             mychar.RorL=2
             mychar.CharState=1
             mychar.move=1

            # mychar.rectpos.left-=5
            # mychar.rectpos.right=mychar.rectpos.left+mychar.xsize
            if event.key==SDLK_RIGHT :
             mychar.RorL=1
             mychar.CharState=1
             mychar.move=1

           #  mychar.rectpos.left+=5
           #  mychar.rectpos.right=mychar.rectpos.left+mychar.xsize
            if event.key==SDLK_UP:
                if mychar.jumcount==0 and mychar.gravitymode==0:
                    mychar.jumcount=5
            if event.key==SDLK_z:
                if mychar.CharState!=3:
                    mychar.CharState=3
                    mychar.aninum=0
        if event.type==SDL_KEYUP and (event.key==SDLK_LEFT or event.key==SDLK_RIGHT): #left 와 right만으로 한이유는 점프이동시 점프키가 때져도 자연스럽게 이동하기위함.
            mychar.CharState=0
            mychar.aninum=0
            mychar.move=0

def draw():
    #그리는건 순서대로다. 현재 내가 하려는방식
    global mychar
    global floor
    global mapimg
    global bgimg
    global mycamera
    global testmonster
    #grass.update()

    clear_canvas()
    #grass.draw()
    bgimg.draw(640,480)
   # bgimg.dynamic_Object_draw(640,480)
    mapimg.draw(1050-mycamera.xpos,379-mycamera.ypos)
    mychar.draw(mycamera)
    testmonster.draw(mycamera)
    #mychar.draw()
   # floor.draw(mycamera)

    update_canvas()




