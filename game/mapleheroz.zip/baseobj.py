from pico2d import *

class RECT:

    def __init__(self):
     self.right=0
     self.left=0
     self.bottom=0
     self.top=0

#밑에꺼 대신 위에껄로 구현하는게 나을듯.
    def Right(self,num):
        self.right=num
    def Left(self,num):
         self.left=num
    def Bottom(self,num):
         self.bottom=num
    def Top(self,num):
         self.top=num


class baseobj:

 def __init__(self):
      #self.RorL=0
      #self.aninum=0
      self.rectpos=RECT()
      self.xpos=0
      self.ypos=0
      self.xsize=0
      self.ysize=0
      #self.timecount=0
      self.rectpos.bottom=0
      self.rectpos.left=0
      self.rectpos.right=0
      self.rectpos.top=0


